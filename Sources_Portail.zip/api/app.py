import code
import pymysql
from os import remove

from flask import Flask, jsonify, request
from db_config import DB_Config
from models import *
from flask_cors import CORS
from methods import *

pymysql.install_as_MySQLdb()
app = Flask(__name__)
app.config.from_object(DB_Config)
cors = CORS(app, resources={r"/*": {"origins": "*"}})
db.init_app(app)


@app.route('/')
def index():
    return "Bienvenue sur l'api, il y a des cookies sur la banquette arrière, servez vous."


@app.route('/sites', methods=['GET'])
def get_sites():
    return jsonify(get_all_sites())


@app.route('/createSite', methods=['POST'])
def create_site():
    data = verify_request_content(request)
    create_new_site(data['site_name'])
    return jsonify({'message': 'Création du site avec succès'})


@app.route('/updateSite', methods=['PUT'])
def update_site():
    data = verify_request_content(request)
    edit_a_site(data['site_id'], data['site_name'])
    return jsonify({'message': "success"})


@app.route('/codes/<site_id>', methods=['GET'])
def get_codes(site_id):
    codes = get_codes_from_a_site(site_id)
    return jsonify([{'ID': code.ID, 'code': code.Code} for code in codes])


@app.route('/sendSMS', methods=['POST'])
def send_sms_all_sites():
    data = verify_request_content(request)
    manage_sms(data)
    return jsonify({'message': 'SMS envoyé avec succès'}, 200)


@app.route('/sendTestSMS', methods=['POST'])
def send_test_sms():
    data = verify_request_content(request)
    send_test_sms(data['phone'], data['message'])
    return jsonify({'meesage': 'SMS envoyé avec succès'})


@app.route('/insert', methods=['POST'])
def insert_codes():
    data = verify_request_content(request)
    insert_codes_on_a_site(data)
    return jsonify({'message': 'success'})


@app.route('/flushSite', methods=['DELETE'])
def flush_site():
    data = verify_request_content(request)
    drop_codes_from_a_site(data["site_id"])
    return jsonify({'message': 'success'})


@app.route('/deleteSite', methods=['DELETE'])
def delete_site():
    data = verify_request_content(request)
    remove_a_site(data["site_id"])
    return jsonify({'message': 'success'})


if __name__ == '__main__':
    app.run(host="0.0.0.0", port=5000)
