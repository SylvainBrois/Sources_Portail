from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()


class Codes(db.Model):
    __tablename__ = 'Codes'
    ID = db.Column(db.Integer, primary_key=True, autoincrement=True)
    ID_Site = db.Column(db.Integer, db.ForeignKey("Sites.ID"), nullable=False)
    Code = db.Column(db.String(6), nullable=False)


class Sites(db.Model):
    __tablename__ = 'Sites'
    ID = db.Column(db.Integer, primary_key=True, autoincrement=True)
    Site_name = db.Column(db.String(12), nullable=False)