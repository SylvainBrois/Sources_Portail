from flask import Flask, jsonify, request
from sqlalchemy import except_
from db_config import DB_Config
from models import *
import config
import requests

def get_all_sites():
    sites = Sites.query.all()
    sites_list = []
    for site in sites:
        site_codes_count = count_codes_from_a_site(site.ID)
        sites_list.append({
            'ID': site.ID,
            'site_name': site.Site_name,
            'count_codes': site_codes_count
        })
    return sites_list


def get_codes_from_a_site(site_id):
    codes = Codes.query.filter_by(ID_Site=site_id).all()
    return codes


def get_first_code_from_a_site(site_id):
    code = Codes.query.filter_by(ID_Site=site_id).first()
    remove_code(code.ID)
    return code.Code


def create_new_site(site_name):
    new_site = Sites(ID=0, Site_name=site_name)
    db.session.add(new_site)
    db.session.commit()
    return


def edit_a_site(site_id, site_name):
    updated_data = Sites.query.get(site_id)
    updated_data.Site_name = site_name
    db.session.commit()
    return


def remove_code(id_code):
    code = Codes.query.get_or_404(id_code)
    db.session.delete(code)
    db.session.commit()
    return


def count_codes_from_a_site(site_id):
    count = Codes.query.filter_by(ID_Site=site_id).count()
    return count


def drop_codes_from_a_site(site_id):
    if count_codes_from_a_site(site_id) > 0:
        codes = get_codes_from_a_site(site_id)
        for code in codes:
            remove_code(code.ID)
        return
    else:
        return


def remove_a_site(site_id):
    drop_codes_from_a_site(site_id)
    try:
        site = Sites.query.get_or_404(site_id)
        db.session.delete(site)
        db.session.commit()
        return jsonify({'message': 'success'})
    except Exception as e:
        return jsonify({'erreur : ': 'le site n\' existe pas'})


def manage_sms(data):
    site_id = data['site_id']
    count = count_codes_from_a_site(site_id)
    if count < 50:
        alert(site_id, count)
    phone = data['phone']
    code_wifi = get_first_code_from_a_site(site_id)
    send_sms(phone, code_wifi)
    return


def send_sms(tel_num, text):
    url = config.SMS_URL
    payload = {
        "numbers": tel_num,
        "text": text
    }
    headers = {
        "X-Api-Key": config.API_KEY,
    }
    response = requests.post(url, data=payload, headers=headers, verify=config.CERT_PATH)
    return response


def send_test_sms(tel_num, text):
    url = config.SMS_URL
    payload = {
        "numbers": tel_num,
        "text": text
    }
    headers = {
        "X-Api-Key": config.API_KEY,
    }
    response = requests.post(url, data=payload, headers=headers, verify=config.CERT_PATH)
    return response


def alert(site_id, count):
    url = config.SMS_URL
    payload = {
        "numbers_csv": 'admins.csv',
        "text": f"Le site {site_id} n'a plus que {count} codes, veuillez en remettre."
    }
    headers = {
        "X-Api-Key": config.API_KEY,
    }
    response = requests.post(url, data=payload, headers=headers, verify=config.CERT_PATH)
    return response


def verify_request_content(request):
    if not request.is_json:
        return jsonify({"error": "La requête doit contenir du JSON"}), 400
    data = request.json
    if not isinstance(data, object):
        return jsonify({"error": "Le JSON doit être une liste d'objets"}), 400
    return data


def insert_codes_on_a_site(data):
    try:
        data_list = data["codes"]
        site_id = data["site_id"]
        for item in data_list:
            code = item["Code"]
            new_data = Codes(ID=0, ID_Site=site_id, Code=code)
            db.session.add(new_data)
        db.session.commit()
        return jsonify({'message': 'Données insérées avec succès'}), 200
    except Exception as e:
        db.session.rollback()
        return jsonify({"error": e}), 500
