import os
import config


class DB_Config:
    SQLALCHEMY_DATABASE_URI = 'mariadb://'+config.DB_USER+':'+config.DB_PASS+'@localhost:3306/'+config.DB_NAME
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    SECRET_KEY = os.urandom(24)
