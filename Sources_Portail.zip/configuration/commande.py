import argparse
import os
import csv
import subprocess

def traiter_fichiers(fichiers):
    """Traiter une liste de fichiers."""
    print("Génération des fichiers de configuration pour rediriger les logs de chaque site vers les fichiers "
          "correspondants.")
    for fichier in fichiers:
        try:
            with open(fichier, mode="r", newline="", encoding="utf-8") as file:
                reader = csv.DictReader(file)
                for row in reader:
                    mac = row["MAC ADDRESS"].replace("-", ":").lower()
                    ap = row["DEVICE NAME"]
                    site = row["SITE NAME"].replace(" ", "_")
                    with open("/etc/rsyslog.d/redirect_" + site + ".conf", "a") as redirect_file:
                        redirect_file.write(
                            "if ($msg contains \"" + mac + "\") then /var/log/portail_captif/" + site + ".log #" + ap +
                            "\"\n&stop\n")
        except FileNotFoundError:
            print(f"Erreur : Le fichier '{csv_file}' n'existe pas.")
    subprocess.run("systemctl restart rsyslog", shell=True, capture_output=True, text=True)

def traiter_dossier(dossier):
    """Lister et traiter tous les fichiers CSV dans un dossier."""
    if not os.path.isdir(dossier):
        print(f"Erreur : {dossier} n'est pas un dossier valide.")
        return

    fichiers_csv = [os.path.join(dossier, f) for f in os.listdir(dossier) if f.endswith('.csv')]
    if not fichiers_csv:
        print(f"Aucun fichier CSV trouvé dans le dossier : {dossier}")
        return

    print(f"Fichiers CSV trouvés dans le dossier {dossier} :")
    for fichier in fichiers_csv:
        print(f"  - {fichier}")
    traiter_fichiers(fichiers_csv)


def main():
    # Configuration des arguments
    parser = argparse.ArgumentParser(
        description="Script pour traiter des fichiers CSV ou un dossier contenant des fichiers CSV.")
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument("-f", "--files", nargs="+", help="Liste des fichiers CSV à traiter.")
    group.add_argument("-d", "--directory", help="Dossier contenant des fichiers CSV.")

    # Analyse des arguments
    args = parser.parse_args()

    if args.files:
        # Traiter les fichiers spécifiés
        fichiers_existants = [f for f in args.files if os.path.isfile(f)]
        if not fichiers_existants:
            print("Erreur : Aucun des fichiers spécifiés n'existe.")
        else:
            traiter_fichiers(fichiers_existants)

    elif args.directory:
        # Traiter le dossier spécifié
        traiter_dossier(args.directory)


if __name__ == "__main__":
    main()
