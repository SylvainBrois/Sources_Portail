db_name="Codes_SMS"
username="SMS_User"
password="SmS_Us3r"
user=$(awk -F: '$3 >= 1000 && $3 < 65534 {print $1}' /etc/passwd)
ip_address=$(hostname -I | awk '{print $1}')

echo "Le script de configuration du système va commencer ses opérations, veuillez ne pas l'arrêter, prêtez bien attention aux actions qui vous seront demandées."

# Installation du dépôt Sury PHP
echo "Installation des dépôts pour PHP 7 et RaspiSMS"
apt install -y apt-transport-https lsb-release ca-certificates wget
wget -O /etc/apt/trusted.gpg.d/php.gpg https://packages.sury.org/php/apt.gpg
echo "deb https://packages.sury.org/php/ $(lsb_release -sc) main" | tee /etc/apt/sources.list.d/php.list
apt update
apt install -y php7.4 php7.4-mbstring php7.4-mysql php7.4-curl

# Installation du dépôt de RaspiSMS 
apt update -y
apt install -y apt-transport-https gnupg2 curl
echo "deb https://apt.raspisms.fr/ buster contrib" | tee -a /etc/apt/sources.list.d/raspisms.list
curl https://apt.raspisms.fr/conf/pub.gpg.key | apt-key add -
apt update -y

# Installation de mariadb 
echo "Installation de MariaDB"
apt install -y mariadb-server

# Contournement de composer
echo "Contournement des contraintes de Composer"
echo "export COMPOSER_ALLOW_SUPERUSER=1" >> /root/.bashrc 
export COMPOSER_ALLOW_SUPERUSER=1

# Installation de RaspiSMS
echo "Installation de RaspiSMS, des actions vous seront demandées, suivez les instruction sur la documentation." 
apt install -y raspisms

# Déplacement des dossiers pour l'API et l'interface de gestion
mv ../api /usr/share/
mv ../dbmanager /var/www/
echo "
<IfModule mod_headers.c>
    Header always set Access-Control-Allow-Origin \"*\"
    Header always set Access-Control-Allow-Methods \"POST, GET, OPTIONS, DELETE, PUT\"
    Header always set Access-Control-Allow-Headers \"X-Requested-With, Content-Type, Authorization, X-Api-Key\"
</IfModule>
RewriteEngine on
RewriteRule ^assets - [L]
RewriteRule ^.well-known - [L]
RewriteRule ^data/public/ - [L]
RewriteRule . index.php
RewriteCond %{REQUEST_METHOD} OPTIONS
RewriteRule ^(.*)$ $1 [R=200,L]
" > /usr/share/raspisms/.htaccess

# Création de la base de données
echo "Création de la base de données : $db_name"
mysql -e "CREATE DATABASE IF NOT EXISTS $db_name;"
echo "Création de l'utilisateur : $username"
mysql -e "CREATE USER IF NOT EXISTS '$username'@'localhost' IDENTIFIED BY '$password';"
echo "Attribution des permissions à l'utilisateur : $username"
mysql -e "GRANT ALL PRIVILEGES ON $db_name.* TO '$username'@'localhost';"
mysql -e "FLUSH PRIVILEGES;"
echo "Création des tables dans la base de données : $db_name"
mysql -u $username -p$password $db_name <<EOF
create table Sites (
  ID int auto_increment primary key,
  Site_name varchar(20) not null
);
create table Codes (
  ID int auto_increment primary key,
  ID_Site int not null,
  Code varchar(6) not null,
  constraint Codes_Sites_ID_fk
    foreign key (ID_Site) references Sites (ID)
);
EOF
echo "Base de données, utilisateur et tables configurés avec succès."

# Configuration de l'API
echo "Préparation de l'API"
apt install -y python3-pip
pip install -r /usr/share/api/requirements.txt --break-system-packages
echo "Identifiant et mot de passe RaspiSMS : "
cat /usr/share/raspisms/.credentials
echo "URL RaspiSMS : http://$ip_address/raspisms"

echo "Veuillez renseigner la clé d'API RaspiSMS. Vous la trouverez dans l'onglet profil sur l'interface web de RaspiSMS."
read -p "Clé d'API : " API_KEY
touch config.py
echo "DB_USER=\"$username\"" >> config.py
echo "DB_NAME=\"$db_name\"" >> config.py
echo "DB_PASS=\"$password\"" >> config.py
echo "API_KEY=\"$API_KEY\"" >> config.py
echo "SMS_URL=\"http://$ip_address/raspisms/scheduled\"" >> config.py
mv config.py /usr/share/api
touch /etc/systemd/system/api.service
echo "
[Unit]
Description=API Pour l envoi de SMS et la gestion de la base de données
After=network.target
[Service]
User= $user
WorkingDirectory=/usr/share/api
ExecStart=/usr/bin/python3 /usr/share/api/app.py
Restart=always
[Install]
WantedBy=multi-user.target
" >> /etc/systemd/system/api.service
systemctl daemon-reload
systemctl enable api.service
systemctl start api.service
touch /var/www/dbmanager/.htaccess
echo  "
AuthType Basic
AuthName \"Zone sécurisée\"
AuthUserFile /var/.secret/.htpasswd
Require valid-user
" > /var/www/dbmanager/.htaccess
touch /var/www/dbmanager/config.js
echo "API_IP=\"$ip_address\"" > /var/www/dbmanager/config.js
mkdir /var/.secret
touch /var/.secret/.htpasswd
echo "Veuillez créer un compte d'administration pour l'application de gestion."
echo "Utilisez ce site https://www.web2generators.com/apache-tools/htpasswd-generator pour créer le compte et copiez/collez les informations qui seront enregistrées dans OUTPUT ci-après : "
read -p "Compte admin : " passwd
echo "$passwd" > /var/.secret/.htpasswd
touch /etc/apache2/sites-enabled/manager.conf
echo "
Alias \"/manager\" \"/var/www/dbmanager\"
<Directory \"/var/www/dbmanager\">
        Require all granted
        Options +FollowSymLinks
        AllowOverride all
</Directory>
" >> /etc/apache2/sites-enabled/manager.conf
systemctl restart apache2.service
python3 parse_lsusb.py $(lsusb)
udevadm control --reload
udevadm trigger
echo "Le script d'installation a terminé ses opérations. Vous allez pouvoir finir manuellement la configuration de raspiSMS et du portail captif."