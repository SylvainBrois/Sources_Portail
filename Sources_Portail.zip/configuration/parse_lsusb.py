import subprocess
import sys
import re
from operator import contains
from unittest import skipIf


def split_lsusb_output(output):
    joined_output = " ".join(output)
    result = re.split(r" Bus", joined_output)
    result = [f"Bus{x}" for x in result if x]
    return result

def get_user():
    command = "awk -F: '$3 >= 1000 && $3 < 65534 {print $1}' /etc/passwd"
    result = subprocess.run(command, shell=True, capture_output=True,text=True)
    user = re.split(r"\n",result.stdout.strip())[0]
    return user


if __name__ == "__main__":
    pattern = r"\b([0-9a-f]{4}:[0-9a-f]{4})\b"
    lsusb_output = sys.argv[1:]
    user=get_user()
    print(lsusb_output)
    split_result = split_lsusb_output(lsusb_output)
    i = 1
    gammu_files_paths = ""
    for line in split_result:
        if not contains(line, "Linux Foundation") and not contains(line, "VMware"):
            result = str(re.findall(pattern, line))
            id_vendor = re.split(":", result)[0][2:6]
            id_product = re.split(":", result)[1][0:4]
            modem_name = "modem" + str(i)
            with open("/etc/udev/rules.d/modems.rules", "a") as f:
                f.write(
                    "SUBSYSTEM==\"tty\", ATTRS{idVendor}==\"" + id_vendor + "\" ATTRS{idProduct}==\"" + id_product + "\" SYMLINK+=\"" + modem_name + "\", MODE=\"0666\"\n")
            gammu_file = "/home/"+user+"/.gammurc-" + modem_name
            with open("/var/log/gammu/"+modem_name+".log", "w") as l :
                pass
            with open(gammu_file, "w") as g:
                g.write("[gammu]\n"
                        "port = /dev/" + modem_name +
                        "\nmodel =\n"
                        "connection = at115200\n"
                        "synchronizetime = yes\n"
                        "logfile = /var/log/gammu/" + modem_name + ".log\n"
                        "logformat = textalldate\n"
                        "use_locking =\ngammuloc=\n")
                gammu_files_paths += gammu_file + "\n"
            i += 1
    print(
        "+------------------------------+\n"
        "Vous trouverez les fichiers de configuration de gammu au bout de ces chemins :\n"
        + gammu_files_paths + 
        "+------------------------------+\n")
