document.addEventListener("DOMContentLoaded", function() {

    fetch(`http://${API_IP}:5000/sites`)
        .then(response => response.json())
        .then(data => {
            data.forEach((item) => {
                 const divCodes = document.createElement('div');
                divCodes.id = item.site_name;
                const h2 = document.createElement('h2');
                h2.textContent = 'Codes '+item.site_name;
                const table = document.createElement('table');
                table.id = 'codesTable'+item.site_name;
                const thead = document.createElement('thead');
                const tr = document.createElement('tr');
                const thID = document.createElement('th');
                const thCode = document.createElement('th');
                const tbody = document.createElement('tbody');
                thID.textContent = 'ID';
                thCode.textContent = 'Code';
                tr.appendChild(thID);
                tr.appendChild(thCode);
                thead.appendChild(tr);
                table.appendChild(thead);
                table.appendChild(tbody);
                divCodes.appendChild(h2);
                divCodes.appendChild(table);
                document.getElementById("table-grid").appendChild(divCodes);
                fetch(`http://${API_IP}:5000/codes/${item.ID}`)
                    .then(response => response.json())
                    .then(data => {
                        tbody.innerHTML = '';
                        data.forEach(item => {
                            const row = tbody.insertRow();
                            const cell1 = row.insertCell(0);
                            const cell2 = row.insertCell(1);
                            cell1.textContent = item.ID;
                            cell2.textContent = item.code;
                        });
                    })

            })
        })
})



