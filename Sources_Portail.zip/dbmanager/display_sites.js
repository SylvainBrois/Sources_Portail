document.addEventListener("DOMContentLoaded", function() {

    fetch(`http://${API_IP}:5000/sites`)
        .then(response => response.json())
        .then(data => {
            const tbody = document.querySelector(`#table-sites tbody`);
            tbody.innerHTML = ''; // Efface les anciennes données
            data.forEach(item => {
                const row = tbody.insertRow();
                const cell1 = row.insertCell(0);
                const cell2 = row.insertCell(1);
                const cell3 = row.insertCell(2);
                const cell4 = row.insertCell(3);
                const cell5 = row.insertCell(4);
                const cell6 = row.insertCell(5);
                const cell7 = row.insertCell(6);
                const insertPicto = document.createElement("img")
                insertPicto.src = 'downloadCodes.png'
                insertPicto.className = "admin-picto"
                const fileInput = document.createElement("input");
                fileInput.type = "file";
                fileInput.accept = ".csv";
                fileInput.style.display = "none"; // Caché par défaut

                // Ajout d'un gestionnaire d'événement à l'image pour déclencher l'input file
                insertPicto.addEventListener("click", function() {
                    fileInput.click(); // Ouvre le sélecteur de fichiers
                });

                fileInput.addEventListener("change", function (event){
                    let place = item.ID
                    let file = event.target.files[0]
                    const reader = new FileReader()
                    reader.onload = function (e){
                        try{
                            const text = e.target.result;
                            const json = csvToJson(text);

                            // Créer un tableau ne contenant que les codes
                            const codes = json.map(item => ({
                                Code: item["Code"].trim()
                            }));
                            // Ajouter le site_id au JSON
                            const payload = {
                                codes: codes,
                                site_id: place
                            };

                            // Créer l'option pour la requête POST
                            const fetchOpt = {
                                method: 'POST',
                                mode: 'cors',
                                cache: 'no-cache',
                                redirect: 'follow',
                                referrer: 'no-referer',
                                headers: {
                                    'Content-Type': 'application/json'
                                },
                                body: JSON.stringify(payload, null, 2)
                            };

                            // Envoyer la requête POST
                            fetch(`http://${API_IP}:5000/insert`, fetchOpt)
                                .then(response => response.json())
                                .then(() => {
                                    console.log("Success");
                                })
                                .catch((error) => {
                                    console.error('Error: ', error);
                                });
                        }catch (err){
                            console.error(err)
                        }
                    }
                    reader.readAsText(file)
                    setTimeout(function() {
                        location.reload();
                    }, 2000);
                })
                function csvToJson(csv) {
                    const lines = csv.split("\n");
                    const headers = lines[0].split(",");

                    const result = [];

                    for (let i = 1; i < lines.length; i++) {
                        if (lines[i].trim() === "") continue;  // Ignore les lignes vides
                        const obj = {};
                        const currentLine = lines[i].split(",");

                        headers.forEach((header, index) => {
                            let value = currentLine[index] ? currentLine[index].trim() : "";
                            value = value.replace(/^['"]+|['"]+$/g, "");
                            obj[header.trim()] = value;
                        });

                        result.push(obj);
                    }
                    return result;
                }
                const editModule = document.createElement("div")
                editModule.className = "edit-module"
                const textInput = document.createElement("input")
                textInput.type = 'text'
                textInput.style.verticalAlign = 'middle'
                const validate = document.createElement("img")
                validate.src = "validateRename.png"
                validate.className = "admin-picto"
                editModule.appendChild(textInput)
                editModule.appendChild(validate)
                validate.addEventListener("click", function (){
                    let changeSiteID = item.ID
                    let changeSiteName = textInput.value;
                    const fetch_body = {
                        "site_id" : changeSiteID,
                        "site_name" : changeSiteName
                    }
                    const options = {
                        method : 'PUT',
                        mode : 'cors',
                        cache : 'no-cache',
                        redirect : 'follow',
                        referrer : 'no-referer',
                        headers : {
                            'Content-Type' : 'application/json'
                        },
                        body : JSON.stringify(fetch_body)
                    }
                    try {

                        fetch(`http://${API_IP}:5000/updateSite`, options)
                            .then(response => response.json())
                            .then(() => {
                                console.log("Success")
                            })
                            .catch((error)=> {
                                console.error('Error: ', error)
                            })
                    }catch (err){
                        console.error("marche po")
                    }
                    setTimeout(function() {
                        location.reload();
                    }, 2000);
                })
                const flushPicto = document.createElement("img")
                flushPicto.src = 'delCodes.png'
                flushPicto.className = "admin-picto"

                flushPicto.addEventListener("click", function () {
                    let flushedSite = item.ID;
                    const fetch_body = {
                        "site_id" : flushedSite,
                    }
                    const options = {
                        method : 'DELETE',
                        mode : 'cors',
                        cache : 'no-cache',
                        redirect : 'follow',
                        referrer : 'no-referer',
                        headers : {
                            'Content-Type' : 'application/json'
                        },
                        body : JSON.stringify(fetch_body)
                    }
                    try {

                        fetch(`http://${API_IP}:5000/flushSite`, options)
                            .then(response => response.json())
                            .then(() => {
                                console.log("Success")
                            })
                            .catch((error)=> {
                                console.error('Error: ', error)
                            })
                    }catch (err){
                        console.error("marche po")
                    }
                    setTimeout(function() {
                        location.reload();
                    }, 4000);
                })

                const delRowPicto = document.createElement("img")
                delRowPicto.src = 'deleteSite.png'
                delRowPicto.className = "admin-picto"
                delRowPicto.addEventListener("click", function () {
                    let deletedSite_ID = item.ID
                    const fetch_body = {
                        "site_id": deletedSite_ID,
                    }
                    const options = {
                        method: 'DELETE',
                        mode: 'cors',
                        cache: 'no-cache',
                        redirect: 'follow',
                        referrer: 'no-referer',
                        headers: {
                            'Content-Type': 'application/json'
                        },
                        body: JSON.stringify(fetch_body)
                    }
                    try {

                        fetch(`http://${API_IP}:5000/deleteSite`, options)
                            .then(response => response.json())
                            .then(() => {
                                console.log("Success")
                            })
                            .catch((error) => {
                                console.error('Error: ', error)
                            })
                    } catch (err) {
                        console.error(err)
                    }
                    setTimeout(function () {
                        location.reload();
                    }, 2000);
                })


                cell1.textContent = item.ID;
                cell2.textContent = item.site_name;
                cell3.textContent = item.count_codes;
                cell4.appendChild(insertPicto);
                cell5.appendChild(editModule)
                cell6.appendChild(flushPicto);
                cell7.appendChild(delRowPicto)
            })
        })
})


