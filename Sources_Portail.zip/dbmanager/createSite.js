document.addEventListener("DOMContentLoaded", function() {

    document.getElementById("btn-create-site").addEventListener("click", function() {
        let newSiteName = document.getElementById("new-site-name").value;
        const fetch_body = {
            "site_name" : newSiteName,
        }
        const options = {
            method : 'POST',
            mode : 'cors',
            cache : 'no-cache',
            redirect : 'follow',
            referrer : 'no-referer',
            headers : {
                'Content-Type' : 'application/json'
            },
            body : JSON.stringify(fetch_body)
        }
        try {

        fetch(`http://${API_IP}:5000/createSite`, options)
            .then(response => response.json())
            .then(() => {
                console.log("Success")
            })
            .catch((error)=> {
                console.error('Error: ', error)
            })
            }catch (err){
        console.error("marche po")
        }
        setTimeout(function() {
            location.reload();
        }, 2000);
    })
})

